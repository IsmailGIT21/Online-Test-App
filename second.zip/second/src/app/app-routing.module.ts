import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AboutUs1Component } from './about-us1/about-us1.component';
import { QuizInstructionComponent } from './quiz-instruction/quiz-instruction.component';
import { QuizComponent } from './quiz/quiz.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { LogicalComponent } from './logical/logical.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
 
  {path: 'quiz', component: QuizComponent},
  {path: 'quiz-instruction', component: QuizInstructionComponent},
  {path: 'about-us1', component: AboutUs1Component},
  {path: 'contact-us', component: ContactUsComponent},
  {path: 'logical', component: LogicalComponent},
  {path: 'home',component: HomeComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule { }
